import pickle
from gensim.models import KeyedVectors
from flask import Flask, request, render_template
from utils import tokenizator, combinator_vector

app=Flask(__name__, template_folder= "templates")

@app.before_first_request
def load_models():
	global classificator
	global w2v_model
	
	w2v_dir = "model_skip.txt"
	classificator_dir = "LR_skip.pkl"
	w2v_model = KeyedVectors.load_word2vec_format(w2v_dir)
	
	with open(classificator_dir, "rb" ) as f:
		classificator = pickle.load(f)
		
@app.route("/")
def home():
	return render_template("form.html")
	
	
@app.route("/", methods=["POST"])
def predict():
	title = next(request.form.values())
	title_tokens = tokenizator(title)
	title_vector = combinator_vector(title_tokens, w2v_model)
	title_category = classificator.predict(title_vector)
	
	
	
	output = title_category[0].capitalize()
	
	return render_template("form.html", final=title, text1=output)
	

if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5002, threaded=True)	
	
	



