import spacy
import numpy as np


nlp = spacy.load("pt_core_news_sm", desable=["parser", "ner", "tagger", "textcat"])


def tokenizator(text):
    doc=nlp(text)
    valid_tokens = []
    for token in doc:
        e_valid = not token.is_stop and token.is_alpha
        if e_valid:
            valid_tokens.append(token.text.lower())
    return valid_tokens
    
    
def combinator_vector(words, model):
    result_vector = np.zeros((1, 300))
    for w in words:
        try:
            result_vector += model.get_vector(w)
        except KeyError:
            pass
    return result_vector    
